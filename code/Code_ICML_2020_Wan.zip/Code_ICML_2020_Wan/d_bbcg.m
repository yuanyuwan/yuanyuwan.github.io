
function ave_loss = d_bbcg(eta_c,delta,maxNorm,P,data,C)
[T,D,N] = size(data);
D = D-1;

%initialization
K = floor(sqrt(T));%block size
L = 20;
loss = zeros(T,N,N);
X = zeros(C,D,N);
Z = zeros(C,D,N);
G = zeros(C,D,N);

eta = eta_c./(T^(3/4));
r = maxNorm/sqrt(min(C,D));

tic
for t = 1:T
    if t > 1 && mod(t,K)==1
        for in = 1:N
            %update the dual variable (middel)
            NEI = find(P(in,:)~=0);
            for iNEI = 1:length(NEI)
                G(:,:,in) = G(:,:,in) + P(in,NEI(iNEI)).*Z(:,:,NEI(iNEI));
            end
        end
        %update the dual variable
        Z = G;
        %reset the cumulative gradient
        G = zeros(C,D,N);
        for in = 1:N
            x = X(:,:,in);
            %iterative linear optimization steps
            for l = 1:L
                %compute the gradient of the surrogate loss
                DF = eta.*Z(:,:,in) + 2.*x;
                
                %linear optimization
                [u,~,v] = lansvd(-DF, 1, 'L', struct('tol',1e-5));
                V = maxNorm.*(1-delta/r).*u*v';
                
                Delta = V - x;
                flag = sum(dot(-DF,Delta));
                if flag <= 1e-5
                    break; %early stop and avoid invalide value of sigma
                end
                sigma = 0.5*flag/sum(dot(Delta,Delta));
                if sigma < 0 || isnan(sigma) || isinf(sigma)
                    fprintf('Invalid value of sigma: %f\n', sigma)
                end
                if sigma > 1
                    sigma = 1;
                end
                x = x + sigma.* Delta;
            end
            X(:,:,in) = x;
        end
    end
    
    Y = zeros(C,D,N);
    %estimate the local gradient
    for in = 1:N
        label = data(t,1,in);
        feat = data(t,2:D+1,in);
        u = randn(C,D);
        u = u./sqrt(sum(sum(u.^2)));
        Y(:,:,in) = X(:,:,in)+delta.*u;
        score = Y(:,:,in)*feat';
        ob_loss = log(sum(exp(score - score(label))));
        G(:,:,in) = G(:,:,in) + (C*D/delta).*ob_loss.*u;
    end
    
    %observe the loss
    for in = 1:N    
        for ob = 1:N
            label = data(t,1,ob);
            feat = data(t,2:D+1,ob);
            score = Y(:,:,in)*feat';
            loss(t,ob,in) = log(sum(exp(score - score(label))));
        end 
    end
    toc
end

loss = sum(loss,3);
loss = sum(loss,2);
x = 1:T;
x = (N*N).*x;
ave_loss = cumsum(loss')./x;
