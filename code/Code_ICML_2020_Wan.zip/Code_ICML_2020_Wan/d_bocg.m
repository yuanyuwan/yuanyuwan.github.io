
function ave_loss = d_bocg(eta_c,maxNorm,P,data,C)
[T,D,N] = size(data);
D = D-1;

%initialization
K = floor(sqrt(T));%block size
L = 20;
loss = zeros(T,N,N);
X = zeros(C,D,N);
Z = zeros(C,D,N);
G = zeros(C,D,N);

eta = eta_c./(T^(3/4));

tic
for t = 1:T
    if t > 1 && mod(t,K)==1
        for in = 1:N
            %update the dual variable (middel)
            NEI = find(P(in,:)~=0);
            for iNEI = 1:length(NEI)
                G(:,:,in) = G(:,:,in) + P(in,NEI(iNEI)).*Z(:,:,NEI(iNEI));
            end
        end
        %update the dual variable
        Z = G;
        %reset the cumulative gradient
        G = zeros(C,D,N);
        %update the local leanrer
        for in = 1:N
            x = X(:,:,in);
            %iterative linear optimization steps
            for l = 1:L
                %compute the gradient of the surrogate loss
                DF = eta.*Z(:,:,in) + 2.*x;
                
                %linear optimization
                [u,~,v] = lansvd(-DF, 1, 'L', struct('tol',1e-5));
                V = maxNorm.*u*v';
                
                %line search
                Delta = V - x;
                flag = sum(dot(-DF,Delta));
                if flag <= 1e-5
                    break; %early stop and avoid invalide value of sigma
                end
                sigma = 0.5*flag/sum(dot(Delta,Delta));
                if sigma < 0 || isnan(sigma) || isinf(sigma)
                    fprintf('Invalid value of sigma: %f\n', sigma)
                end
                if sigma > 1
                    sigma = 1;
                end
                
                %update decision (middel)
                x = x + sigma.* Delta;
            end
            X(:,:,in) = x;
        end
    end
    
    %compute the local gradient
    for in = 1:N
        label = data(t,1,in);
        feat = data(t,2:D+1,in);
        score = X(:,:,in)*feat';
        score = exp(score - score(label));
        tol_score = sum(score);
        for CLA = 1:C
            if CLA ~= label    
                G(CLA,:,in) = G(CLA,:,in) + score(CLA)/tol_score.*feat;
            else
                G(CLA,:,in) = G(CLA,:,in) + (1-tol_score)/tol_score.*feat;
            end
        end
    end
    
    %observe the loss
    for in = 1:N    
        for ob = 1:N
            label = data(t,1,ob);
            feat = data(t,2:D+1,ob);
            score = X(:,:,in)*feat';
            loss(t,ob,in) = log(sum(exp(score - score(label))));
        end 
    end
    toc
end

loss = sum(loss,3);
loss = sum(loss,2);
x = 1:T;
x = (N*N).*x;
ave_loss = cumsum(loss')./x;
