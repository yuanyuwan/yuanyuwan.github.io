clear
clc

seed = 1; % fix seed to have consistent outcome 
rng(seed);

%set the input data
all_data = load('./datasets/aloi_scale');
all_data(:,1) = all_data(:,1) + 1; %from [0,1,...,999] to [1,2,...,1000]
C = max(all_data(:,1));

N = 9;

%set the radius of the decision set
maxNorm = 50;

%divide data for N nodes
[all_T, D] = size(all_data);
D = D - 1;
seq = randperm(all_T);
all_data = all_data(seq,:);
T = all_T/N;
data = zeros(T,D+1,N);

for i = 1:N
    data(1:T,:,i) = all_data((i-1)*T+1:i*T,:);
end
clear all_data

%generate weight matrix
P = zeros(N,N);
P(1,1) = 1.0/3;
P(1,N) = 1.0/3;
P(1,2) = 1.0/3;
P(N,1) = 1.0/3;
P(N,N) = 1.0/3;
P(N,N-1) = 1.0/3;
for i = 2:N-1
    P(i,i-1) = 1.0/3;
    P(i,i) = 1.0/3;
    P(i,i+1) = 1.0/3;
end

%D-OCG
loss_d_ocg = d_ocg(1e3,maxNorm,P,data,C);

%D-BOCG
loss_d_bocg = d_bocg(1e3,maxNorm,P,data,C);

%plot results
com_rounds = [];

T = length(loss_d_bocg);
K = floor(sqrt(T));
for t = 1:T
    if t > 1 && mod(t,K)==1
        com_rounds = [com_rounds,t];
    end
end
x = 1:length(com_rounds);
x_ocg = 0:2000;
createfigure_aloi(x,loss_d_bocg(com_rounds),x_ocg,loss_d_ocg(x_ocg+1))
