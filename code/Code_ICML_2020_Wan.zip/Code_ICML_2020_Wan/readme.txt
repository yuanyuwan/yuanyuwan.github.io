
# Description
The package includes the code and datasets used in the paper "Yuanyu Wan, Wei-Wei Tu, Lijun Zhang. Projection-free Distributed Online Convex Optimization with $O(\sqrt{T})$ Communication Complexity. ICML 2020.".

# How to run?
1.Install the PROPACK package, which is used to compute the top-1 SVD and already included in this package. The code should work on both Windows and Linux system. For more information about PROPACK, please refer to http://sun.stanford.edu/~rmunk/PROPACK/.
2.Run aloi_exp.m for the experiment on the aloi dataset.
3.Run poker_exp.m for the experiment on the poker dataset.

# Other Specific Functions
d_bocg.m -> The D-BOCG algorithm in the paper.
d_bbcg.m -> The D-BBCG algorithm in the paper.
d_ocg.m -> The D-OCG algorithm in "Wenpeng Zhang, Peilin Zhao, Wenwu Zhu, Steven C. H. Hoi, Tong Zhang. Projection-free Distributed Online Learning in Networks. ICML 2017.".
createfigure_aloi.m -> Plot the results for the experiment on the aloi dataset.
createfigure_poker.m -> Plot the results for the experiment on the poker dataset.

# Datasets are downloaded from https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/multiclass.html. We only modified the format of the orginal datasets to make them easy to load. 




